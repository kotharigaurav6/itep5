package A;
public class Aclass 
{
    public void show(){
        System.out.println("show method of class A called");
    }
}
