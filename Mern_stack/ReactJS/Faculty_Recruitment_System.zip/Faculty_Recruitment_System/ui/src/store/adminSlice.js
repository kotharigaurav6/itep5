import { createSlice } from "@reduxjs/toolkit";
import axios from 'axios';
import { admin_requestedUrl } from "../urls.js";
import jscookie from 'js-cookie';
var admin_token = jscookie.get("admin_jwt_token");

const initialState = {
//    email:""
}

const adminSlice = createSlice({
    name:'adminSlice',
    initialState,
    reducers : {
        // setEmail : (state,action)=>{
        //     state.email = action.payload
        // }
    }
});

export const adminLogin =async (adminCredential)=>{  
    try{
        console.log(adminCredential);
        var result = await axios.post(admin_requestedUrl+'/adminLogin',adminCredential); 
        console.log("adminSlice : ",result);
        console.log("token : ",result.data.token);
        if(result.status==201)
            jscookie.set("admin_email",adminCredential.email);

        jscookie.set('admin_jwt_token',result.data.token,{expires:1});
        return result;
    }catch(err){
        console.log("error in adminSlice : ",err);
    }
}
export const viewRecruiterList =async ()=>{  
    try{
        var result = await axios.get(admin_requestedUrl+'/recruiterList?adminToken='+admin_token); 
        console.log("recruiterList : ",result);
        return result;
    }catch(err){
        console.log("error in admin recruiterList : ",err);
    }
}

export const adminVerifyRecruiter =async (recruiterEmail)=>{  
    try{
        var result = await axios.get(admin_requestedUrl+'/adminVerifyRecruiter?adminToken='+admin_token+'&_id='+recruiterEmail); 
        console.log("recruiterList : ",result);
        return result;
    }catch(err){
        console.log("error in admin recruiterList : ",err);
    }
}

//export const {setEmail} = adminSlice.actions;
export default adminSlice.reducer;