public class QueueDemo {

    int arr[], currentSize = 0, rear, front, capacity;

    public QueueDemo(int size) {
        this.capacity = size;
        this.arr = new int[this.capacity];
        rear = -1;
        front = 0;
    }
    public void inqueue(int data){
        if(isFull())
            System.out.println("Queue is full..!!");
        else{
            rear++;
            arr[rear]=data;
            currentSize++;
            System.out.println(arr[rear]+" inserted");
        }
    }
    public void dequeue(){
        if(isEmpty())
               System.out.println("Queue is empty..!!");
        else{
            front++;
            System.out.println(arr[front-1]+" is removed");
            currentSize--;
        }
    }
    public boolean isEmpty(){
        if(currentSize==0)
            return true;
        return false;
    }
    public boolean isFull(){
        if(capacity==currentSize)
            return true;
        return false;
    }
    public static void main(String[] args) {
        QueueDemo queue = new QueueDemo(6);
        queue.dequeue();
        queue.inqueue(12);
           queue.dequeue();
        queue.inqueue(43);
        queue.inqueue(56);
           queue.dequeue();
        queue.inqueue(21);
        queue.inqueue(30);
        queue.inqueue(32);
            queue.dequeue();

          for(int i=queue.front;i<=queue.rear;i++){
              System.out.print("\t"+queue.arr[i]);
          }
          System.out.println("\ncurrent size : "+queue.currentSize);
    }
}
