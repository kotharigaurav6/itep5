import { addCandidate } from "../store/candidateSlice.js";
import {useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';
import {useSelector} from 'react-redux';

function CandidateRegistration(){
  const [candidate,setCandidate] = useState({});
  const navigate = useNavigate();
  const getData = (event)=>{
      let {name,value} = event.target;
      if(event.target.type=='file'){
          value = event.target.files[0];
          setCandidate({
            ...candidate,
            [name]:value
        });            
      }else{
      setCandidate({
          ...candidate,
          [name]:value
      });
    }
  }

  const handleSubmit = (event)=>{
      event.preventDefault();
      const formData = new FormData();
      for(var index in candidate){
        if(candidate[index]){
          formData.append(index,candidate[index])
        }
      }

      addCandidate(formData);
      navigate("/candidateLogin",{
        state:{
          message:"Email Sent | Please verify and wait for admin approval"
        }
      });
  }
    return (<>
<section style={{marginTop: "-50px"}} className="w3l-index3">
  <div className="midd-w3 py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row">
        <div className="col-lg-6 left-wthree-img text-right">
          <img src="assets/images/g5.jpg" alt="" className="img-fluid rounded" />
        </div>
        <div className="col-lg-6 mt-lg-0 mt-5 about-right-faq">
          <h3 className="text-da">Candidate Registration</h3>
          <br/>
          {/* action="/candidate/candidateRegistration" */}
          <form onSubmit={handleSubmit} method="post" className="form-group" enctype="multipart/form-data">
            <input onChange={getData} required className="form-control" type="text" placeholder="Enter Candidate Name" id="name" name="name"/>
            
            <input onChange={getData} required className="form-control" type="email" placeholder="Enter Email" id="email" name="email"/>
            
            <input onChange={getData} required className="form-control" type="password" placeholder="Enter Password" id="password" name="password"/>

            <select onChange={getData} required name="gender" id="gender" className="form-control">
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
             </select> 
 
            <label>DOB</label>
            <input onChange={getData} required className="form-control" type="date" id="date" name="date"/>
 
            <textarea onChange={getData} required name="address" id="address" className="form-control" placeholder="Enter Address"></textarea>
 
            <input onChange={getData} required className="form-control" type="text" placeholder="Enter 10-digit mobile number" id="contact" name="contact"/>
            
            <input onChange={getData} required className="form-control" type="text" placeholder="Enter Qualification" id="qualification" name="qualification"/>
             
            <input onChange={getData} required className="form-control" type="number" step="0.1" placeholder="Enter Percentage" id="percentage" name="percentage"/>
 
            <select onChange={getData} required name="experience" id="experience" className="form-control">
                <option value="">Select Experience</option>
                <option value="Fresher">Fresher</option>
                <option value="0-12 months">0-12 months</option>
                <option value="1+ Year">1+ Year</option>
                <option value="2+ Year">2+ Year</option>
                <option value="3+ Year">3+ Year</option>
                <option value="4+ Year">4+ Year</option>
                <option value="5+ Year">5+ Year</option>
            </select>
            <label>Upload CV/Resume</label>
            <input onChange={getData} required type="file" id="docs" name="docs"/>

            <input className="btn btn-primary btn-block" type="submit" value="Register"/> 
            
            <input className="btn btn-danger btn-block" type="reset" value="Reset"/>
            
            
          </form>
          <Link to="/candidateLogin">
            <span className="btn btn-link">Already Registered ? Login Here</span>
          </Link> 
        </div>
      </div>
    </div>
  </div>
</section>
    
    </>);
}
export default CandidateRegistration;