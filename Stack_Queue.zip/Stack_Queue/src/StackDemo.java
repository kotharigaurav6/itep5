public class StackDemo 
{
    int arr[],top,size;
    public StackDemo(int size) {
        this.size=size;
        this.top=-1;
        this.arr=new int[this.size];
    }
    public void push(int data){
        if(!isFull())
        {
            top++;
            arr[top] = data;
            System.out.println(data+" added successfully");
        }else
            System.out.println("Stack is full..!!");
    } 
    public void pop(){
        if(!isEmpty()){
            System.out.println(arr[top]+" is removed");
            top--;
        }
        else
        {
            System.out.println("Stack is empty..!!");
        }
    }
    public boolean isFull(){
        if(top==size-1)
               return true;
        else
                return false;
    }
    public boolean isEmpty(){
        if(top==-1)
            return true;
        else
               return false;
    }
    public static void main(String[] args) {
        StackDemo stack = new StackDemo(5);
        stack.pop();
        stack.push(234);
            stack.pop();
        stack.push(321);
        stack.push(400);
            stack.pop();
        stack.push(123);
        stack.push(567);
        stack.push(324);
            stack.pop();
    
            System.out.println("Stack elements : ");
//            for(int i=stack.size-1;i>=0;i--){
//                System.out.println(stack.arr[i]);
//            }
            for(int i=stack.top;i>=0;i--){
                System.out.println(stack.arr[i]);
            }
    }
}
