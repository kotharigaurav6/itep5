import mypackage.OperationDemo;
import java.util.Scanner;
public class NewClass 
{
    public static void main(String[] args) {
        OperationDemo obj = new OperationDemo();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter values of a and b : ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        
        System.out.println("Sum : "+obj.sum(a, b));
        System.out.println("Sub : "+obj.sub());
    }
}
