import {Link,useNavigate,useLocation} from 'react-router-dom';
import {useState} from 'react';
import {adminLogin} from '../store/adminSlice.js';
import { useDispatch } from 'react-redux';
//import { setEmail } from '../store/adminSlice.js';   
function Admin(){
    const [adminCredential,setAdminCredential] = useState();
    const navigate = useNavigate();
    const location = useLocation();
    const dispatch = useDispatch();

    const getData = (event)=>{
      const {name,value} = event.target;
      setAdminCredential({
        ...adminCredential,
        [name]:value
      });
    }
    const handleSubmit = (event)=>{
    event.preventDefault();
      var result = adminLogin(adminCredential);
      console.log("result of admin : ",result);
      result.then((resultData)=>{
           console.log(resultData);
           console.log("result of admin email : ",resultData.data.adminemail);
           console.log("result of admin status : ",resultData.status);
           if(resultData.status==201){
  //          dispatch(setEmail(resultData.data.adminemail));
            navigate("/adminHome",{
                state:{
                  email : resultData.data.adminemail
                }
              });
            }else if(resultData.status==203){
              navigate("/admin",{
                state:{
                  message : resultData.data.message
                }
              });
            }
      });
      
    }
return (<>
        <section style={{marginTop: "-50px"}} className="w3l-index3">
  <div className="midd-w3 py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row">
        <div className="col-lg-6 left-wthree-img text-right">
          <img src="assets/images/g5.jpg" alt="" className="img-fluid rounded" />
        </div>
        <div className="col-lg-6 mt-lg-0 mt-5 about-right-faq">
            <br/><br/>
          <h3 className="text-da">Admin Login</h3>
          <h6>{location.state==null ? "" : location.state.message}</h6>
          <br/>
          {/* /admin/adminLogin */}
            <form onSubmit={handleSubmit} className="form-group" method="post">
                <input className="form-control" onChange={getData} type="email" placeholder="Enter Email" id="email" name="email"/> <br/>
                <input className="form-control" onChange={getData} type="password" placeholder="Enter Password" id="password" name="password"/> <br/>
                <input className="btn btn-primary btn-block" type="submit" value="Login"/> 
                <input className="btn btn-danger btn-block" type="reset" value="Reset"/>
                <br/>
            </form>
        </div>
      </div>
    </div>
  </div>
</section>

</>);
}
export default Admin;