import AppliedVacancy from '../model/appliedVacancyModel.js';
import Vacancy from '../model/vacancyModel.js';

export const applyVacancyController = async(request,response)=>{
     var vacancyObj = request.body; 
     var vid = vacancyObj._id;
     var candidateemail = vacancyObj.candidateemail;
     var recruiteremail = vacancyObj.recruiteremail;
     var post = vacancyObj.post;
    
     var obj = {vid,candidateemail,recruiteremail,post};
     try{
            var check = {
                $and:[
                    {vid:vid},
                    {candidateemail:candidateemail}
                ]
            };
            var status = await AppliedVacancy.findOne(check);
            console.log("Applied status : ",status);
            if(!status){
                var appliedObj = await AppliedVacancy.create(obj);
                console.log("appliedObj : ",appliedObj);
                console.log("Applied for Vacancy Successfully");
    
                var vacancyList = await Vacancy.find();
                //response.render("candidateVacancyList",{result:vacancyList,candidateemail:request.payload._id,message:"Applied for Vacancy Successfully"});
                response.status(201).json({result:vacancyList});
    
            }else{
                var vacancyList = await Vacancy.find();
                //response.render("candidateVacancyList",{result:vacancyList,candidateemail:request.payload._id,message:"Already Applied for Vacancy"});
                console.log("ccccccccccv : ",vacancyList);
                response.status(211).json();
                //response.status(211).json({result:vacancyList});

            }
       
        }catch(err){
        console.log("Error while Applying for vacancy inside applied vacancy controller : "+err);
        //response.render("error",{message:"Error while Applying for vacancy inside applied vacancy controller"});
        response.status(203).json({message:"Error while Applying for vacancy inside applied vacancy controller"});
    } 
  
  };
  
