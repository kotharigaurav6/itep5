import {viewVacancyStatus} from '../store/candidateSlice.js';
import {useEffect,useState} from 'react';
import { useSelector } from 'react-redux';
import { setNavBar } from '../store/commonSlice.js';
import { useDispatch } from 'react-redux';
function CandidateVacancyStatus(){
    const [vacancyStatus,setVacancyStatus]  = useState([]);
    const dispatch = useDispatch();
    const candidateemail = useSelector(state=>state.candidateSlice.email);
    useEffect(()=>{
        dispatch(setNavBar("candidateHome"));

        var res = viewVacancyStatus();
        res.then((vacancy)=>{
            if(vacancy.status==200){
                setVacancyStatus(vacancy.data.result);
            }
        }).catch((err)=>{
            console.log(err);
        });
    },[]);

    return (<>
    <section class="w3l-index2" id="services">
  <div class="features-main py-5 text-center">
    <div class="container py-lg-3">
      <div class="heading mx-auto">
        <h4 class="head">Status</h4>
      <br/>  
      </div>

        <table border="1" style={{fontSize:"11px"}} cellPadding="10" cellSpacing="0" width="100%">
            <thead>
                <tr>
                    <th>Vacancy Id</th>
                    <th>Candidate Email</th>
                    <th>Recruiter Email</th>
                    <th>Post</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                {
                    vacancyStatus.map((vacancy)=>{
                        return(<tr>
                            <td>{vacancy._id}</td>
                            <td>{vacancy.candidateemail}</td>
                            <td>{vacancy.recruiteremail}</td>
                            <td>{vacancy.post}</td>
                            <td>{vacancy.status}</td>

                        </tr>)
                    })
                }
                {/* <%result.forEach((candidateList,i)=>{%>
                  <tr>
                    <td><%=candidateList.vid%></td>
                    <td><%=candidateList.candidateemail%></td>
                    <td><%=candidateList.recruiteremail%></td>
                    <td><%=candidateList.post%></td>
                    <td><%=candidateList.status%></td>
                  </tr>  
                <%})%> */}
            </tbody>
            <tfoot>
                <tr>
                    <th>Vacancy Id</th>
                    <th>Candidate Email</th>
                    <th>Recruiter Email</th>
                    <th>Post</th>
                    <th>Status</th>
                </tr>
            </tfoot>
        </table>

    </div>
  </div>
</section>

    </>);
}

export default CandidateVacancyStatus;