import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.*;

public class SwingDemo3 extends JFrame implements ActionListener{
    JLabel lb1,lb2,lb3;
    JTextField txt1;
    JButton btn;
    
    public SwingDemo3(){
            setTitle("My First Example");
            setLayout(null);
            setSize(600, 600);
            setLocation(200, 200);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Font font = new Font("Candara", Font.BOLD, 24);
            
            lb1 = new JLabel("Welcome To Swing Example");
            lb1.setBounds(50, 50, 300, 30);
            lb1.setFont(font);
            add(lb1);
            
            lb2 = new JLabel("Enter Text");
            lb2.setBounds(50, 110, 150, 30);
            lb2.setFont(font);
            add(lb2);

            txt1 = new JTextField();
            txt1.setBounds(210, 100, 300, 40);
            txt1.setFont(font);
            add(txt1);

            btn = new JButton("Submit");
            btn.setBounds(210, 170, 300, 40);
            btn.setFont(font);
            add(btn);

            lb3 = new JLabel();
            lb3.setBounds(50, 220, 400, 40);
            lb3.setFont(font);
            add(lb3);

            btn.addActionListener(this);
            setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btn){
            lb3.setText("Your Text : "+txt1.getText());
        }
    }
            
        public static void main(String[] args) {
            new SwingDemo3();
        }
}
