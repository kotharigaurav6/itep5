import { createSlice } from "@reduxjs/toolkit";
import axios from 'axios';
import { recruiter_requestedUrl } from "../urls.js";
import jscookie from 'js-cookie';
var recruiter_token = jscookie.get("recruiter_jwt_token");

const initialState = {
    message:"",
//    email : ""
}

const recruiterSlice = createSlice({
    name:'recruiterSlice',
    initialState,
    reducers : {
        setMessage:(state,action)=>{
            state.message = action.payload;
        },
        // setEmail : (state,action)=>{
        //     state.email = action.payload
        // }
    }
});

export const addRecruiter =async (recruiter)=>{  
    try{
        console.log(recruiter);
        var result = await axios.post(recruiter_requestedUrl+'/recruiterRegistration',recruiter); 
        console.log("recruiterSlice : ",result);
        console.log("token : ",result.data.token);
        jscookie.set('recruiter_jwt_token',result.data.token,{expires:1});
    }catch(err){
        console.log("error in recruiterSlice : ",err);
    }
}
export const recruiterLogin =async (recruiterCredential)=>{  
    try{
        console.log(recruiterCredential);
        var result = await axios.post(recruiter_requestedUrl+'/recruiterLogin',recruiterCredential); 
        console.log("recruiterSlice : ",result);
        console.log("token : ",result.data.token);
        if(result.status==201)
            jscookie.set("recruiter_email",recruiterCredential.email);
            
        jscookie.set('recruiter_jwt_token',result.data.token,{expires:1});
        return result;
    }catch(err){
        console.log("error in recruiterSlice : ",err);
    }
}
export const updateStatus = async (vacancyId)=>{  
    try{
        var result = await axios.get(recruiter_requestedUrl+'/updateCandidateStatus?recruiterToken='+recruiter_token+'&_id='+vacancyId); 
        console.log("List : ",result);
        return result;
    }catch(err){
        console.log("error in recruiter update status : ",err);
    }
}


//export const {setEmail} = recruiterSlice.actions;
export default recruiterSlice.reducer;