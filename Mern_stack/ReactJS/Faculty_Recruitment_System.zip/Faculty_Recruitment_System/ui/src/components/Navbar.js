import { useEffect,useState } from "react";
import { useSelector,useDispatch } from "react-redux";
import {Link,useNavigate} from 'react-router-dom';
import jscookie from 'js-cookie';
import { setNavBar } from "../store/commonSlice.js";

function Navbar(){
    const [menuItem,setMenuItem] = useState();
    const navShow = useSelector(state=>state.commonSlice.navShow);
    console.log(navShow);
   const navigate = useNavigate();
   const dispatch = useDispatch();
    const recruiterLogout = ()=>{
      jscookie.set("recruiter_email",null);
      jscookie.remove("recruiter_jwt_token");
      dispatch(setNavBar("home"));
      navigate("/");
    }
    const candidateLogout = ()=>{
      jscookie.set("candidate_email",null);
      jscookie.remove("candidate_jwt_token");
      dispatch(setNavBar("home"));
      navigate("/");
    }
    const adminLogout = ()=>{
      jscookie.set("admin_email",null);
      jscookie.remove("admin_jwt_token");
      dispatch(setNavBar("home"));
      navigate("/");
    }
    useEffect(()=>{
        const result = setInterval(() => {
         // console.log(navShow);
            if(navShow=="home"){
                setMenuItem(<ul className="nav-inner">
                <li><Link to="/"><span id='navstyle'>Home</span></Link></li>
                <li><Link to="#"><span id='navstyle'>About</span></Link></li>
                <li><Link to="#"><span id='navstyle'>Contact</span></Link></li>
                <li><Link to="/recruiterLogin"><span id='navstyle'>Recruiter</span></Link></li>
                <li><Link to="/candidateLogin"><span id='navstyle'>Candidate</span></Link></li>
              </ul>);
            }else if(navShow=="adminHome"){
              setMenuItem(<ul class="nav-inner">
                <li><Link to="/adminHome"><span id='navstyle'>Home</span></Link></li>
                <li><span id='navstyle'>List &#9662;</span>
                  <ul>
                      <li><Link to=""><span id='navstyle'>Candidate List</span></Link></li><br/>
                      <li><Link to="/recruiterList"><span id='navstyle'>Recruiter List</span></Link></li><br/>
                      <li><Link to=""><span id='navstyle'>Vacancy List</span></Link></li><br/>
                      <li><Link to=""><span id='navstyle'>Applied Candidate List</span></Link></li><br/>
                  </ul>
                </li>
                <li><Link to=""><span id='navstyle'>Update Password</span></Link></li>
                <li><span id='navstyle' onClick={adminLogout}>Logout</span></li>
            </ul>);
            }else if(navShow=="recruiterHome"){
              setMenuItem(<ul class="nav-inner">
                <li><Link to="/recruiterHome"><span id='navstyle'>Home</span></Link></li>
                <li><span id='navstyle'>List &#9662;</span>
                  <ul>
                      <li><Link to="/addVacancy"><span id='navstyle'>Add Vacancy</span></Link></li><br/>
                      <li><Link to="/recruiterViewVacancy"><span id='navstyle'>Vacancy List</span></Link></li><br/>
                      <li><Link to="/appliedCandidateList"><span id='navstyle'>Applied Candidate List</span></Link></li><br/>
                      <li><Link to=""><span id='navstyle'>UpdateProfile</span></Link></li><br/>
                      <li><Link to=""><span id='navstyle'>DeActivate Account</span></Link></li><br/>
                 </ul>
                </li>
                <li><Link to=""><span id='navstyle'>Update Password</span></Link></li>
                <li><span id='navstyle' onClick={recruiterLogout}>Logout</span></li>
            </ul>);
            }else if(navShow=="candidateHome"){
              setMenuItem(<ul class="nav-inner">
                <li><Link to="/candidateHome"><span id='navstyle'>Home</span></Link></li>
                <li><span id='navstyle'>List &#9662;</span>
                  <ul>
                      <li><Link to="/candidateViewVacancy"><span id='navstyle'>View Vacancy</span></Link></li><br/>
                      <li><Link to="/candidateVacancyStatus"><span id='navstyle'>Vacancy Status</span></Link></li><br/>
                      <li><Link to=""><span id='navstyle'>UpdateProfile</span></Link></li><br/>
                      <li><Link to=""><span id='navstyle'>DeActivate Account</span></Link></li><br/>
                 </ul>
                </li>
                <li><Link to=""><span id='navstyle'>Update Password</span></Link></li>
                <li><span id='navstyle' onClick={candidateLogout}>Logout</span></li>
            </ul>);
            }
        });
    
          return ()=>{clearInterval(result);}
    },[navShow]);
    return (<>
<section class="w3l-header">
      <div class="header-right d-flex align-items-center">
      <a class="navbar-brand" href="index.html"><span class="fa fa-smile-o"></span>शिक्षक<label class="logo-view">&nbsp;Recruitment</label></a>
      
          <div id="nav">
            {/* #################################### */}
                    {menuItem}

            {/* ##################################### */}
          </div>
      </div>
</section>

    </>);
}
export default Navbar;