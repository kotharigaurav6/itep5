import {useEffect, useState} from 'react';
import { addVacancy,updateVacancy } from "../store/vacancySlice.js";
import {useNavigate} from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setNavBar } from '../store/commonSlice.js';
function AddVacancy(){
    const [vacancy,setVacancy] = useState({});
    const [vacancyobj,setVacancyObj] = useState({});
    const navigate = useNavigate();
    const location = useLocation();
    const dispatch = useDispatch();

    useEffect(()=>{
      dispatch(setNavBar("recruiterHome"));
      if(location.state!=null){
        setVacancyObj(location.state.vacancyobj);  
      }
    },[]);
    const getData = (event)=>{
        const{name,value} = event.target;
        setVacancy({
            ...vacancy,
            [name]:value
        });
    }
    const handleSubmit = (event)=>{
        event.preventDefault();
        if(location.state==null){
          addVacancy(vacancy).then((result)=>{
            console.log("addvacancy : ",result);
            if(result.status==201){
              alert("Vacancy Added Successfully");
              navigate("/recruiterHome",{
                state:{
                  email:result.data.recruiteremail
                }
              });
            }
          }).catch((err)=>{
              console.log(err);
          });
        }else{
          updateVacancy(vacancy,vacancyobj._id).then((result)=>{
            console.log("updatevacancy : ",result);
            if(result.status==200){
              alert("Vacancy Updated Successfully");
              navigate("/recruiterViewVacancy");
            }
          }).catch((err)=>{
              console.log(err);
          });
        }
    }   
    return (<>
    <section style={{marginTop: "-100px"}} className="w3l-index3">
  <div className="midd-w3 py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row">
        <div className="col-lg-6 left-wthree-img text-right">
          <img src="assets/images/g5.jpg" alt="" className="img-fluid rounded" />
        </div>
        <div className="col-lg-6 mt-lg-0 mt-5 about-right-faq">
          <h3 className="text-da">
            {location.state==null ? "Add Vacancy" : "Update Vacancy"}
          </h3>
          {/* <h6><%=message%></h6> */}
          {/* action="/vacancy/addVacancy" */}
          
          <form  onSubmit={handleSubmit} method="post" className="form-group">
            <input defaultValue={vacancyobj.post} required className="form-control" type="text" placeholder="Enter Post" id="post" onChange={getData} name="post"/>
            
            <select required onChange={getData} name="subject" id="subject" className="form-control">
                <option value={location.state==null ? "" : vacancyobj.subject}>{location.state==null ? "Select Subject" : vacancyobj.subject}</option>
                <option value="Primary Subjects">Primary Subjects</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Biology">Biology</option>
                <option value="Accounts">Accounts</option>
                <option value="Business Studies">Business Studies</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Data Structure">Data Structure</option>
                <option value="IP">IP</option>
                <option value="AI">AI</option>
                <option value="Data Base">Data Base</option>
                <option value="Cloud Computing">Cloud Computing</option>
                <option value="Computer Graphics">Computer Graphics</option>

            </select>
            
            <input defaultValue={vacancyobj.location} required onChange={getData} className="form-control" type="text" placeholder="Enter Location" id="location" name="location"/>

            <select required onChange={getData} name="criteria" id="criteria" className="form-control">
                <option value={location.state==null ? "" : vacancyobj.criteria}>{location.state==null ? "Select Criteria" : vacancyobj.criteria}</option>
                <option value="B.ED">B.ED</option>
                <option value="D.ED">D.ED</option>
                <option value="Graduate">Graduate</option>
                <option value="Post Graduate">Post Graduate</option>
                <option value="PHD">PHD</option>
            </select>
            
            <select required onChange={getData} name="experience" id="experience" className="form-control">
                <option value={location.state==null ? "" : vacancyobj.experience}>{location.state==null ? "Select Experience" : vacancyobj.experience}</option>
                <option value="Fresher">Fresher</option>
                <option value="0-12 months">0-12 months</option>
                <option value="1+ Year">1+ Year</option>
                <option value="2+ Year">2+ Year</option>
                <option value="3+ Year">3+ Year</option>
                <option value="4+ Year">4+ Year</option>
                <option value="5+ Year">5+ Year</option>
            </select>

            <select required onChange={getData} name="duration" id="duration" className="form-control">
                <option value={location.state==null ? "" : vacancyobj.duration}>{location.state==null ? "Select Duration" : vacancyobj.duration}</option>
                <option value="Part Time">Part Time</option>
                <option value="Full Time">Full Time</option>
            </select>

            <input defaultValue={vacancyobj.vacancy} required onChange={getData} className="form-control" type="number" min="1" placeholder="Enter No. of Vacancy" id="vacancy" name="vacancy"/>

            <input defaultValue={vacancyobj.salary} required onChange={getData} className="form-control" type="number" min="5000" placeholder="Enter salary" id="salary" name="salary"/>
            <label>Advertisement Date</label>
            <input defaultValue={vacancyobj.advdate} required onChange={getData} className="form-control" type="date" id="advdate" name="advdate"/>
            <label>Last Date</label>
            <input defaultValue={vacancyobj.lastdate} required onChange={getData} className="form-control" type="date" id="lastdate" name="lastdate"/>
            
            <input className="btn btn-primary btn-block" type="submit" value={location.state==null ? "Add Vacancy" : "Update Vacancy"}/> 
            
            <input className="btn btn-danger btn-block" type="reset" value="Reset"/>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
</>);
}
export default AddVacancy;
