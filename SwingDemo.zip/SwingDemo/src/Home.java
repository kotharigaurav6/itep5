import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
public class Home extends JFrame implements ActionListener
{
    JButton btn1,btn2,btn3;
    public Home(){
        setTitle("Home Page");
        setLocation(200,200);
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        
        btn1 = new JButton("Login");
        btn1.setBounds(150, 50, 300, 45);
        btn1.setFont(new Font("Candara",Font.BOLD,24));
        add(btn1);

        btn2 = new JButton("Registration");
        btn2.setBounds(150, 110, 300, 45);
        btn2.setFont(new Font("Candara",Font.BOLD,24));
        add(btn2);

        btn3 = new JButton("View Users");
        btn3.setBounds(150, 170, 300, 45);
        btn3.setFont(new Font("Candara",Font.BOLD,24));
        add(btn3);

        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btn1){
        //    JOptionPane.showMessageDialog(new Home(), "Button 1 clicked");
            dispose();
            Login login = new Login();
            login.setVisible(true);
        }
        if(e.getSource()==btn2){
         //   JOptionPane.showMessageDialog(new Home(), "Button 2 clicked");
            dispose();
            Registration register = new Registration();
            register.setVisible(true);
        }
        if(e.getSource()==btn3){
         //   JOptionPane.showMessageDialog(new Home(), "Button 3 clicked");
            dispose();
            Profile profile = new Profile();
            profile.setVisible(true);
        }

    }
    public static void main(String[] args) {
        new Home();
    }
}
