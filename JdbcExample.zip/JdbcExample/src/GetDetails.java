public interface GetDetails 
{
    String URL = "jdbc:mysql://localhost:3306/itep5";
    String USER = "root";
    String PASS = "root";    
}
