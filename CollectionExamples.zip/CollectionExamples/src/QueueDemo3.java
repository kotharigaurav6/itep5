import java.util.*;
public class QueueDemo3 
{
    public static void main(String[] args) {
        ArrayDeque<String> queue = new  ArrayDeque<>();
     
      queue.offer("Andrew");
      queue.offerLast("Jackson");
      queue.offer("Simon");
      queue.offerFirst("simon");
      queue.offerFirst("mathew");
      
      System.out.println("Elements : "+queue);
              
        System.out.println("element : "+queue.element());
        System.out.println("Elements : "+queue);

        System.out.println("peek : "+queue.peek());
        System.out.println("Elements : "+queue);

        System.out.println("remove : "+queue.remove());
        System.out.println("Elements : "+queue);

        System.out.println("poll : "+queue.poll());
        System.out.println("Elements : "+queue);
      
    }
}
