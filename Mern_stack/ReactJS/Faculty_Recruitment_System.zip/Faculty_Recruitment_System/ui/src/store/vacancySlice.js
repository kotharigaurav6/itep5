import { createSlice } from "@reduxjs/toolkit";
import axios from 'axios';
import { vacancy_requestedUrl } from "../urls.js";
import jscookie from 'js-cookie';
var recruiter_token = jscookie.get("recruiter_jwt_token");

const initialState = {
    message:""
}

const vacancySlice = createSlice({
    name:'vacancySlice',
    initialState,
    reducers : {
        setMessage:(state,action)=>{
            state.initialState = action.payload;
        }
    }
});

export const addVacancy =async (vacancy)=>{  
    try{
        console.log(vacancy);
        var result = await axios.post(vacancy_requestedUrl+'/addVacancy?recruiterToken='+recruiter_token,vacancy); 
        console.log("vacancySlice : ",result);
        return result;
    }catch(err){
        console.log("error in vacancySlice : ",err);
    }
}

export const viewVacancyList =async ()=>{  
    try{
        var result = await axios.get(vacancy_requestedUrl+'/recruiterViewVacancy?recruiterToken='+recruiter_token); 
        console.log("vacancyList : ",result);
        return result;
    }catch(err){
        console.log("error in vacancy vacancyList : ",err);
    }
}

export const viewAppliedCandidateList =async ()=>{  
    try{
        var result = await axios.get(vacancy_requestedUrl+'/appliedCandidate?recruiterToken='+recruiter_token); 
        console.log("vacancyList : ",result);
        return result;
    }catch(err){
        console.log("error in vacancy vacancyList : ",err);
    }
}

export const deleteVacancy =async (vacancyId)=>{  
    try{
        var result = await axios.get(vacancy_requestedUrl+'/deleteVacancy?recruiterToken='+recruiter_token+'&vacancyid='+vacancyId); 
        console.log("vacancyList : ",result);
        return result;
    }catch(err){
        console.log("error in vacancy delete vacancy : ",err);
    }
}

export const updateVacancy =async (vacancy,vacancy_id)=>{  
    try{
        console.log(vacancy);
        var result = await axios.put(vacancy_requestedUrl+'/updateVacancy?recruiterToken='+recruiter_token+'&_id='+vacancy_id,vacancy); 
        console.log("vacancySlice : ",result);
        return result;
    }catch(err){
        console.log("error in update vacancy : ",err);
    }
}

// export const {} = vacancySlice.actions;
export default vacancySlice.reducer;