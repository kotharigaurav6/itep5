import express from 'express';
import { recruiterRegistrationController,recruiterEmailController,recruiterLoginController,recruiterLogoutController,recruiterUpdateCandidateStatusController } from '../controller/recruiterController.js';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';

dotenv.config();
var secret_key = process.env.SECRET_KEY;

export const authenticateJWT = (request,response,next)=>{
    //var token = request.cookies.jwt_token;
   // var token = request.param("recruiterToken");
   var token = request.query.recruiterToken; 
   console.log("token : ",token);
    if(!token)
//        response.render("recruiterLogin",{message:""});
    response.status(203).json({message:"Token not found"});
    else{    
        jwt.verify(token,secret_key,(err,payload)=>{
            if(err)
//                response.render("recruiterLogin",{message:""});
                  response.status(203).json({message:"Error while verifying Token"});
            else{
                request.payload = payload;
                next();
            }    
        });
    }    
}

var recruiterRouter = express.Router();

//recruiterRouter.use(express.static('public'));


recruiterRouter.post("/recruiterRegistration",recruiterRegistrationController);
recruiterRouter.get("/verifyemail",recruiterEmailController);
recruiterRouter.post("/recruiterLogin",recruiterLoginController);
recruiterRouter.get("/addVacancy",authenticateJWT,(request,response)=>{
    response.render("addVacancy",{message:""});
});
recruiterRouter.get("/updateCandidateStatus",authenticateJWT,recruiterUpdateCandidateStatusController);
recruiterRouter.get("/recruiterLogout",recruiterLogoutController);

export default recruiterRouter;