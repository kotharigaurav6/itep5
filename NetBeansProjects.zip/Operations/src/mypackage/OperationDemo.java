package mypackage;
import java.util.Scanner;
public class OperationDemo 
{
    public int sum(int a,int b){
        return a+b;
    }

    public int sub(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter values of a and b : ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        return a-b;
    }

}
