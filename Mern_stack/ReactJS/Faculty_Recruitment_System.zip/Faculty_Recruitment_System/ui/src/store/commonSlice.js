import { createSlice } from "@reduxjs/toolkit";
const initialState = {
    navShow : "home"
}

const commonSlice = createSlice({
    name:'commonSlice',
    initialState,
    reducers : {
        setNavBar : (state,action)=>{
            state.navShow = action.payload
            console.log("navShow : ",state.navShow);
        }
    }
});

export const {setNavBar} = commonSlice.actions;
export default commonSlice.reducer;