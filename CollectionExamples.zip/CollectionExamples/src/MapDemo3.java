import java.util.*;
import java.util.Scanner;
public class MapDemo3 
{
    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
        System.out.println("Enter no. of entries : ");
        int ent = sc.nextInt();
        int key;
        String value;
        TreeMap<Integer,String> map = new TreeMap<>();
        
        for(int i=0;i<ent;i++)
        {
            System.out.println("Enter key : ");
            key = sc.nextInt();
                sc.nextLine();
            System.out.println("Enter value : ");
            value = sc.nextLine();
            
            map.put(key,value);
        }
        for(Map.Entry obj : map.entrySet()){
              System.out.println("Key : "+obj.getKey()+"\tValue : "+obj.getValue());       
        }
    }
}
