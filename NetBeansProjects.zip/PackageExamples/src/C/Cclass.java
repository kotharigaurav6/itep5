package C;
import A.Aclass;
public class Cclass extends Aclass
{
    public void draw(){
        System.out.println("draw method of class C called");
        show();
    }
}
