import express from 'express';
import { adminLoginController,adminLogoutController,adminRecruiterListController,adminVerifyRecruiterController } from '../controller/adminController.js';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';

dotenv.config();
var secret_key = process.env.ADMIN_SECRET_KEY;

const authenticateJWT = (request,response,next)=>{
    var token = request.param("adminToken");
    console.log('------> ',token);
    if(!token)
//        response.render("adminLogin",{message:""});
          response.status(203).json({message:"Trying to enter explicitly"});         
    else{    
        jwt.verify(token,secret_key,(err,payload)=>{
            if(err)
                // response.render("adminLogin",{message:""});
                response.status(203).json({message:"Trying to enter explicitly"});         
            else{
                request.payload = payload;
                next();
            }    
        });
    }    
}

var adminRouter = express.Router();

//adminRouter.use(express.static('public'));


adminRouter.post("/adminLogin",adminLoginController);
adminRouter.get("/adminLogout",adminLogoutController);
adminRouter.get("/recruiterList",authenticateJWT,adminRecruiterListController);
adminRouter.get("/adminVerifyRecruiter",authenticateJWT,adminVerifyRecruiterController);

export default adminRouter;