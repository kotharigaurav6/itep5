import {viewRecruiterList,adminVerifyRecruiter} from '../store/adminSlice.js';
import {useEffect,useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setNavBar } from '../store/commonSlice.js';
function RecruiterList(){
    const navigate = useNavigate();
    const dispatch = useDispatch();
  //  let recruitList = []; //React does not re-render the component if any of the values other than the state changes
    const [recruiterList,setRecruiterList]  = useState([]);
    useEffect(()=>{
        dispatch(setNavBar("adminHome"));

        var res = viewRecruiterList();
        res.then((recruiter)=>{
            if(recruiter.status==203){
                navigate("/admin",{
                    state:{
                        message:recruiter.data.message
                    }
                });
            }else if(recruiter.status==200){
                setRecruiterList(recruiter.data.result);
            }
        }).catch((err)=>{
            console.log(err);
        });
    },[]);

    const adminVerify = (recruiterEmail)=>{
        console.log("@@@@@@@",recruiterEmail);
        var res = adminVerifyRecruiter(recruiterEmail);
        console.log("##########",res);
        res.then((recruiter)=>{
            if(recruiter.status==203){
                navigate("/admin",{
                    state:{
                        message:recruiter.data.message
                    }
                });
            }else if(recruiter.status==200){
                console.log("$$$$$$$$$$$ : ",recruiter);
                setRecruiterList(recruiter.data.result);
            }
        }).catch((err)=>{
            console.log(err);
        });
    }
    return (<>
    <section class="w3l-index2" id="services">
  <div class="features-main py-5 text-center">
    <div class="container py-lg-3">
      <div class="heading mx-auto">
        <h4 class="head">Recruiter List</h4>
      <br/>  
      </div>

        <table border="1" cellpadding="10" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th>Email Verify</th>
                    <th>Admin Verify</th>
                </tr>
            </thead>
            <tbody>
            {
                recruiterList.map((recruiter)=>{
                    return (<tr>
                        <td>{recruiter.name}</td>
                        <td>{recruiter.type}</td>
                        <td>{recruiter._id}</td>
                        <td>{recruiter.contact}</td>
                        <td>{recruiter.address}</td>
                        <td>{String(recruiter.status)}</td>
                        <td>{recruiter.emailverify}</td>
                        <td><button onClick={()=>{adminVerify(recruiter._id)}}>{recruiter.adminverify}</button></td>
                    </tr>);
                })
            }
                {/* <%result.forEach((recruiterList)=>{%>
                  <tr>
                    <td><%=recruiterList.name%></td>
                    <td><%=recruiterList.type%></td>
                    <td><%=recruiterList._id%></td>
                    <td><%=recruiterList.contact%></td>
                    <td><%=recruiterList.address%></td>
                    <td><%=recruiterList.status%></td>
                    <td><%=recruiterList.emailverify%></td>
                    <td><a href="/admin/adminVerifyRecruiter?_id=<%=recruiterList._id%>"><%=recruiterList.adminverify%></a></td>
                  </tr>  
                <%})%> */}
            </tbody>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th>Email Verify</th>
                    <th>Admin Verify</th>
                </tr>
            </tfoot>
        </table>

    </div>
  </div>
</section>
    </>);
}
export default RecruiterList;