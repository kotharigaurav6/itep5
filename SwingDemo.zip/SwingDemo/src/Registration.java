import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Registration extends JFrame implements ActionListener{
    JLabel lb1,lb2,lb3,lb4;
    JTextField txt1,txt2,txt3;
    JButton btn;
    
    public Registration(){
        setTitle("Registration Page");
        setLocation(200,200);
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
       
            lb1 = new JLabel("Registration Form");
            lb1.setBounds(50, 50, 300, 30);
            lb1.setFont(new Font("Candara",Font.BOLD,24));
            add(lb1);
            
            lb2 = new JLabel("Enter Email");
            lb2.setBounds(50, 110, 150, 30);
            lb2.setFont(new Font("Candara",Font.BOLD,24));
            add(lb2);

            lb3 = new JLabel("Enter Password");
            lb3.setBounds(50, 150, 150, 30);
            lb3.setFont(new Font("Candara",Font.BOLD,24));
            add(lb3);

            lb4 = new JLabel("Enter Address");
            lb4.setBounds(50, 190, 150, 30);
            lb4.setFont(new Font("Candara",Font.BOLD,24));
            add(lb4);

            txt1 = new JTextField();
            txt1.setBounds(210, 100, 300, 40);
            txt1.setFont(new Font("Candara",Font.BOLD,24));
            add(txt1);
            
            txt2 = new JTextField();
            txt2.setBounds(210, 150, 300, 40);
            txt2.setFont(new Font("Candara",Font.BOLD,24));
            add(txt2);

            txt3 = new JTextField();
            txt3.setBounds(210, 200, 300, 40);
            txt3.setFont(new Font("Candara",Font.BOLD,24));
            add(txt3);

            btn = new JButton("Register");
            btn.setBounds(210, 250, 300, 40);
            btn.setFont(new Font("Candara",Font.BOLD,24));
            add(btn);

            btn.addActionListener(this);
        
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btn){
            String email = txt1.getText();
            String password = txt2.getText();
            String address = txt3.getText();
            
            Connection con = MyConnection1.getConnect();
            try
            {
                String query = "insert into user(email,password,address) values(?,?,?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1,email);
                ps.setString(2,password);
                ps.setString(3,address);
                
                  int i = ps.executeUpdate();
                  if(i>0)
                  {
                      dispose();
                      JOptionPane.showMessageDialog(new Registration(), "Registration Successfull");
                      new Login();
                  }else{
                      JOptionPane.showMessageDialog(new Registration(), "Error while Registering");                      
                  }
            
            }catch(SQLException E){
                System.out.println("Exception : "+e);
            }
        }
    }
}
