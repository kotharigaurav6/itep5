import express from 'express';
var indexRouter = express.Router();

export default indexRouter;