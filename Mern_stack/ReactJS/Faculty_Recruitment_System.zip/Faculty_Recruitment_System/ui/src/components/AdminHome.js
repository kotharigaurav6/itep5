import { useEffect } from 'react';
import { useDispatch,useSelector } from 'react-redux';
import {Link,useNavigate,useLocation} from 'react-router-dom';
import { setNavBar } from '../store/commonSlice.js';
import jscookie from 'js-cookie';
function AdminHome(){
    const location = useLocation();
//    const adminemail =  useSelector(state=>state.adminSlice.email);
    const dispatch = useDispatch();
//    console.log(adminemail);
    const navigate = useNavigate();
    const admin_email = jscookie.get("admin_email");

    useEffect(()=>{
      if(admin_email=="null"){
        dispatch(setNavBar("home"));
        navigate("/");
      }
      else  
        dispatch(setNavBar("adminHome"));
    },[]);
    return (<>
<div className="w3l-index-block1">
  <div className="content py-5">
    <div className="container py-lg-4">
      <div className="row align-items-center">
        <div className="col-lg-5 content-left">
          <h3>Admin Panel</h3>
          <h5>{admin_email}</h5>
          <p className="mt-3 mb-lg-5 mb-4">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
          <Link to="about.html" className="btn btn-primary btn-style">Get Started</Link>
        </div>
        <div className="col-lg-7 content-photo mt-lg-0 mt-5">
          <img src="assets/images/main.jpg" className="img-fluid" alt="main image"/>
        </div>
      </div>
      <div className="clear"></div>
    </div>
  </div>
</div>

    </>);
}
export default AdminHome;