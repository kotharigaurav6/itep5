import {viewVacancyList,candidateApplyVacancy} from '../store/candidateSlice.js';
import {useEffect,useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector,useDispatch } from 'react-redux';
import { setNavBar } from '../store/commonSlice.js';
function CandidateVacancyList(){
    const navigate = useNavigate();
    const dispatch = useDispatch();
      const [vacancyList,setVacancyList]  = useState([]);
      const candidateemail = useSelector(state=>state.candidateSlice.email);
      useEffect(()=>{
        dispatch(setNavBar("candidateHome"));

          var res = viewVacancyList();
          res.then((vacancy)=>{
              if(vacancy.status==203){
                  navigate("/candidateLogin",{
                      state:{
                          message:vacancy.data.message
                      }
                  });
              }else if(vacancy.status==200){
                  setVacancyList(vacancy.data.result);
              }
          }).catch((err)=>{
              console.log(err);
          });
      },[]);
      const candidate_apply_vacancy = (vacancyObj)=>{
        console.log(vacancyObj);
        var result = candidateApplyVacancy(vacancyObj);
        console.log(result);
        result.then((vacancy)=>{
            if(vacancy.status==201){
                alert("Vacancy Applied Successfully");
                setVacancyList(vacancy.data.result);
            }else if(vacancy.status==211){
                alert("Already Applied");
//                setVacancyList(vacancy.data.result);
                console.log("cvvvvv : ",vacancy.data.result);
            }else if(vacancy.status==203){
                console.log("error in candidate vacancy list");
            }
        })
    }
    return (<>
    <section class="w3l-index2" id="services">
  <div class="features-main py-5 text-center">
    <div class="container py-lg-3">
      <div class="heading mx-auto">
        <h4 class="head">Vacancy List</h4>
        {/* <center><h6><%=message%></h6></center> */}
      <br/>  
      </div>

        <table border="1" style={{fontSize:"11px"}} cellPadding="10" cellSpacing="0" width="100%">
            <thead>
                <tr>
                    <th>Post</th>
                    <th>Subject</th>
                    <th>Location</th>
                    <th>Criteria</th>
                    <th>Experience</th>
                    <th>Duration</th>
                    <th>Vacancy</th>
                    <th>Salary</th>
                    <th>Adv.Date</th>
                    <th>LastDate</th>
                    <th>Recruiter <br/> Email</th>
                    <th>Recruiter <br/> Type</th>
                    <th>Recruiter <br/> Name</th>
                    <th>Apply</th>
                </tr>
            </thead>
            <tbody>
            {
                vacancyList.map((vacancy)=>{
                    // <td><a href="/appliedVacancy/applyVacancy?
                    // _id=<%=vacancyList._id%>
                    // &candidateemail=<%=candidateemail%>
                    // &recruiteremail=<%=vacancyList.recruiteremail%>
                    // &post=<%=vacancyList.post%>">Apply</a></td>

                    var vacancyObj = {
                        ...vacancy,
                        candidateemail    
                    }

                    return (<tr>
                        <td>{vacancy.post}</td>
                        <td>{vacancy.subject}</td>
                        <td>{vacancy.location}</td>
                        <td>{vacancy.criteria}</td>
                        <td>{vacancy.experience}</td>
                        <td>{vacancy.duration}</td>
                        <td>{vacancy.vacancy}</td>
                        <td>{vacancy.salary}</td>
                        <td>{vacancy.advdate}</td>
                        <td>{vacancy.lastdate}</td>
                        <td>{vacancy.recruiteremail}</td>
                        <td>{vacancy.recruitertype}</td>
                        <td>{vacancy.recruitername}</td>
                        <td><button onClick={()=>{candidate_apply_vacancy(vacancyObj)}}>Apply</button></td>

                    </tr>);
                })
            }
                {/* <%result.forEach((vacancyList)=>{%>
                  <tr>
                    <td><%=vacancyList.post%></td>
                    <td><%=vacancyList.subject%></td>
                    <td><%=vacancyList.location%></td>
                    <td><%=vacancyList.criteria%></td>
                    <td><%=vacancyList.experience%></td>
                    <td><%=vacancyList.duration%></td>
                    <td><%=vacancyList.vacancy%></td>
                    <td><%=vacancyList.salary%></td>
                    <td><%=vacancyList.advdate%></td>
                    <td><%=vacancyList.lastdate%></td>
                    <td><%=vacancyList.recruiteremail%></td>
                    <td><%=vacancyList.recruitertype%></td>
                    <td><%=vacancyList.recruitername%></td>
                    <td><a href="/appliedVacancy/applyVacancy?_id=<%=vacancyList._id%>&candidateemail=<%=candidateemail%>&recruiteremail=<%=vacancyList.recruiteremail%>&post=<%=vacancyList.post%>">Apply</a></td>
                  </tr>  
                <%})%> */}
            </tbody>
            <tfoot>
                <tr>
                    <th>Post</th>
                    <th>Subject</th>
                    <th>Location</th>
                    <th>Criteria</th>
                    <th>Experience</th>
                    <th>Duration</th>
                    <th>Vacancy</th>
                    <th>Salary</th>
                    <th>Adv.Date</th>
                    <th>LastDate</th>
                    <th>Recruiter <br/> Email</th>
                    <th>Recruiter <br/> Type</th>
                    <th>Recruiter <br/> Name</th>
                    <th>Apply</th>
                </tr>
            </tfoot>
        </table>

    </div>
  </div>
</section>

    </>);
}
export default CandidateVacancyList;