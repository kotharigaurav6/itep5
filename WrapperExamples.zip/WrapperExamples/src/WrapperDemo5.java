public class WrapperDemo5 
{
    public static void main(String[] args) {
        char ch='a';
        System.out.println(""+Character.isAlphabetic(ch));
        System.out.println(""+Character.isDigit(ch));
        System.out.println(""+Character.isSpace(ch));
        System.out.println(""+Character.isWhitespace(ch));
        System.out.println(""+Character.isLowerCase(ch));
        System.out.println(""+Character.isUpperCase(ch));
    }
}
