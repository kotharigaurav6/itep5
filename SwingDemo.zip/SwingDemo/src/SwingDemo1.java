import javax.swing.JFrame;
public class SwingDemo1 {
        public static void main(String[] args) {
            JFrame frame = new JFrame();
            frame.setTitle("My First Example");
            frame.setLayout(null);
            frame.setSize(400, 400);
            frame.setLocation(200, 200);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
    }
}
