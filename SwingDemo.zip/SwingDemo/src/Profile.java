import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Profile extends JFrame{
    JScrollPane jScrollPane1;
    JTable jTable1;
    JButton btn;
    public Profile(){
        setTitle("Profile Page");
        setLocation(200,200);
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        
        btn = new JButton("Back");
        btn.setBounds(50, 50,120, 30);
        add(btn);
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Connection con = MyConnection1.getConnect();
            try
            {
                String query1 = "select count(*) from user";
                PreparedStatement ps1 = con.prepareStatement(query1);
                ResultSet rs1 = ps1.executeQuery();
                int count=0;
                if(rs1.next())
                    count = rs1.getInt(1);
                
                String query = "select * from user";
                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();
                
                Object model[][] = new Object [count][3]; 
                for(int i=0;rs.next();i++)
                {
                    for(int j=0;j<3;j++){
                        model[i][j] = rs.getString(j+1);
                    }
                }
                
            jTable1.setModel(new javax.swing.table.DefaultTableModel(
            model,
            new String [] {
                "Email", "Password", "Address"
            }
        ));

            }catch(SQLException e){
                System.out.println("Exception : "+e);
            }
               
        jScrollPane1.setViewportView(jTable1);
        
 javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 570, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(283, Short.MAX_VALUE))
        );
        
        setVisible(true);
    }
}
