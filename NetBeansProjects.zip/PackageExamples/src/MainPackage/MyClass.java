package MainPackage;

import B.Bclass;
import C.Cclass;

public class MyClass {
    public static void main(String[] args) {
        Bclass bobj = new Bclass();
        Cclass cobj = new Cclass();
        
            bobj.display();
            cobj.draw();
    }
}
