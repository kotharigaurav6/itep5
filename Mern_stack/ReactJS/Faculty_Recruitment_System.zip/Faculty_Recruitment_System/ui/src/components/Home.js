function Home(){
    return (<>
          <div className="w3l-index-block1">
  <div className="content py-5">
    <div className="container py-lg-4">
      <div className="row align-items-center">
        <div className="col-lg-5 content-left">
          <h3>Design <br/>Develop <br/>Digital Market</h3>
          <p className="mt-3 mb-lg-5 mb-4">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
          <a href="about.html" className="btn btn-primary btn-style">Get Started</a>
        </div>
        <div className="col-lg-7 content-photo mt-lg-0 mt-5">
          <img src="assets/images/main.jpg" className="img-fluid" alt="main image"/>
        </div>
      </div>
      <div className="clear"></div>
    </div>
  </div>
</div>

<section className="w3l-index2" id="services">
  <div className="features-main py-5 text-center">
    <div className="container py-lg-3">
      <div className="heading mx-auto">
        <h3 className="head">We Provide Best Services</h3>
        <p className="mb-4">Lorem ipsum dolor sit amet elit. Quo ut voluptate assumenda fugiat quas tempore.</p>
      </div>
      <div className="row features">
        <div className="col-lg-4 col-md-6 feature-grid">
          <a href="#url">
            <div className="feature-body service1">
              <div className="feature-img">
                <span className="fa fa-bar-chart" aria-hidden="true"></span>
              </div>
              <div className="feature-info mt-4">
                <h3 className="feature-titel mb-2">Marketing Services</h3>
                <p className="feature-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis nam, minima iste molestiae.
                </p>
              </div>
            </div>
          </a>
        </div>
        <div className="col-lg-4 col-md-6 feature-grid">
          <a href="#url">
          <div className="feature-body service2">
            <div className="feature-img">
              <span className="fa fa-laptop icon-fea" aria-hidden="true"></span>
            </div>
            <div className="feature-info mt-4">
              <h3 className="feature-titel mb-2">Web App Development</h3>
              <p className="feature-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis nam, minima iste molestiae.
              </p>

            </div>
          </div>
          </a>
        </div>
        <div className="col-lg-4 col-md-6 feature-grid">
          <a href="#url">
          <div className="feature-body service3">
            <div className="feature-img">
              <span className="fa fa-line-chart" aria-hidden="true"></span>
            </div>
            <div className="feature-info mt-4">
              <h3 className="feature-titel mb-2">24/7 Call Center Service</h3>
              <p className="feature-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis nam, minima iste molestiae.
              </p>
              <div className="hover">
              </div>
            </div>
          </div>
          </a>
        </div>
        <div className="col-lg-4 col-md-6 feature-grid">
          <a href="#url">
          <div className="feature-body service4">
            <div className="feature-img">
              <span className="fa fa-envelope-o" aria-hidden="true"></span>
            </div>
            <div className="feature-info mt-4">
              <h3 className="feature-titel mb-2">Social Media Marketing</h3>
              <p className="feature-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis nam, minima iste molestiae.
              </p>
            </div>
          </div>
          </a>
        </div>
        <div className="col-lg-4 col-md-6 feature-grid">
          <a href="#url">
          <div className="feature-body service5">
            <div className="feature-img">
              <span className="fa fa-signal icon-fea" aria-hidden="true"></span>
            </div>
            <div className="feature-info mt-4">
              <h3 className="feature-titel mb-2">Corporate Business</h3>
              <p className="feature-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis nam, minima iste molestiae.
              </p>
            </div>
          </div>
          </a>
        </div>
        <div className="col-lg-4 col-md-6 feature-grid">
          <a href="#url">
          <div className="feature-body service6">
            <div className="feature-img">
              <span className="fa fa-paint-brush icon-fea" aria-hidden="true"></span>
            </div>
            <div className="feature-info mt-4">
              <h3 className="feature-titel mb-2">Creative Consultancy</h3>
              <p className="feature-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis nam, minima iste molestiae.
              </p>
            </div>
          </div>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
<section className="w3l-index3">
  <div className="midd-w3 py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row">
        <div className="col-lg-6 left-wthree-img text-right">
          <img src="assets/images/g5.jpg" alt="" className="img-fluid rounded" />
        </div>
        <div className="col-lg-6 mt-lg-0 mt-5 about-right-faq">
          <h6>Your Most Trusted Business Partner</h6>
          <h3 className="text-da">25 Years of Industry Experience</h3>
          <p className="mt-3">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
            ultrices in ligula. Semper at tempufddfel.</p>
          <ul className="w3l-right-book mt-4">
            <li><span className="fa fa-check" aria-hidden="true"></span>Creative Websites Design</li>
            <li><span className="fa fa-check" aria-hidden="true"></span>Accounting Procedures Guidebook</li>
            <li><span className="fa fa-check" aria-hidden="true"></span>Cost Accounting Fundamentals</li>
            <li><span className="fa fa-check" aria-hidden="true"></span>Corporate Cash Management</li>
            <li><span className="fa fa-check" aria-hidden="true"></span>SEO Optimization Services</li>
          </ul>
          <a href="about.html" className="btn btn-outline-style btn-outline-primary mt-4 py-3">Read More</a>
        </div>
      </div>
    </div>
  </div>
</section>
<div className="video-responsive">
	<video className="video" muted="muted" loop="loop" autoplay="autoplay">
		<source src="assets/videos/meeting.mp4" type="video/mp4"/>
		Your browser does not support HTML5 video.
	</video>

	<canvas className="canvas"></canvas>

	<div id="over_video">
		<div className="bg-mask">
			<div className="video-heading">
				<h3>Corporate Agency for Your Business Solutions</h3>
				<p>It is a long established fact that a reader will be distracted by the readable content of a page when
					looking at its layout.</p>
			</div>

		</div>
	</div>
</div>

<section className="w3l-section-title" id="clients">
  <div className="new-block py-5">
    <div className="container pt-lg-5">
      <div className="row">
      <div className="col-md-4 title">
        <h3>Our Clients</h3>
      </div>
      <div className="col-md-8 title-text">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae eligendi minima accusantium reiciendis, cupiditate optio corrupti quis quam at!.</p>
      </div>
    </div>
    </div>
  </div>
</section>
<section className="w3l-logos pb-5 pt-4">
  <div className="container pb-lg-3">
    <div className="row">
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo1.jpg" alt="company-logo" className="img-fluid" />
      </div>
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo2.jpg" alt="company-logo" className="img-fluid" />
      </div>
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo3.jpg" alt="company-logo" className="img-fluid" />
      </div>
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo4.jpg" alt="company-logo" className="img-fluid" />
      </div>
    </div>
    <div className="row mt-lg-4 mt-0">
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo3.jpg" alt="company-logo" className="img-fluid" />
      </div>
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo4.jpg" alt="company-logo" className="img-fluid" />
      </div>
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo1.jpg" alt="company-logo" className="img-fluid" />
      </div>
      <div className="col-lg-3 col-6 logo-view">
        <img src="assets/images/logo2.jpg" alt="company-logo" className="img-fluid" />
      </div>
    </div>
  </div>
</section>
<div className="w3l-index6" id="news">

  <section id="grids5-block" className="py-5">
    <div className="container py-lg-3">
      <div className="heading text-center">
        <h3 className="head">Our Latest News</h3>
        <p>Lorem ipsum dolor sit amet elit. Quo ut voluptate assumenda fugiat quas tempore.</p>
      </div>
      <div className="row">
        <div className="col-lg-4 col-md-6 mt-5">
          <div className="grids5-info">
            <a href="#blog-single.html"><img src="assets/images/g6.jpg" alt="" className="rounded" /></a>
            <div className="blog-info">
              <h4><a href="#blog-single.html">Creative Websites Design</a></h4>
              <ul className="blog-list">
                <li>
                  <p><span className="fa fa-calendar-o"></span> Jan 24, 2020</p>
                </li>
                <li>
                  <p><span className="fa fa-comments-o"></span> <strong>23</strong> comments</p>
                </li>
              </ul>
              <p>Nulla eu ipsum tempus est et vitae nulla empus est
                suscipit et dolor amet.</p>
              <a href="#blog-single.html" className="btn btn-outline-secondary mt-4">Read More</a>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-md-6 mt-5">
          <div className="grids5-info">
            <a href="#blog-single.html"><img src="assets/images/g2.jpg" alt="" className="rounded" /></a>
            <div className="blog-info">
              <h4><a href="#blog-single.html">SEO Optimization Services</a></h4>
              <ul className="blog-list">
                <li>
                  <p><span className="fa fa-calendar-o"></span> Mar 14, 2020</p>
                </li>
                <li>
                  <p><span className="fa fa-comments-o"></span> <strong>12</strong> comments</p>
                </li>
              </ul>
              <p>Nulla eu ipsum tempus est et vitae nulla empus est
                suscipit et dolor amet.</p>
              <a href="#blog-single.html" className="btn btn-outline-secondary mt-4">Read More</a>
            </div>
          </div>
        </div>
        <div className="col-lg-4 offset-md-3 offset-lg-0 col-md-6 mt-5">
          <div className="grids5-info">
            <a href="#blog-single.html"><img src="assets/images/g3.jpg" alt="" className="rounded" /></a>
            <div className="blog-info">
              <h4><a href="#blog-single.html">Corporate Management</a></h4>
              <ul className="blog-list">
                <li>
                  <p><span className="fa fa-calendar-o"></span> Oct 05, 2020</p>
                </li>
                <li>
                  <p><span className="fa fa-comments-o"></span> <strong>16</strong> comments</p>
                </li>
              </ul>
              <p>Nulla eu ipsum tempus est et vitae nulla empus est
                suscipit et dolor amet.</p>
              <a href="#blog-single.html" className="btn btn-outline-secondary mt-4">Read More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<section className="w3l-index4">
  <div className="section-four gotocontact py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row align-items-center">
        <div className="col-xl-7 col-lg-6">
          <div className="heading white">
            <h3>We have offered the best pricing
              to make life easier!</h3>
            <p className="mt-4">Consulting Agency for Your Business!</p>
          </div>
        </div>
        <div className="offset-xl-1 offset-0 col-xl-3 col-lg-6 text-lg-right mt-5 mt-lg-0">
          <a className="btn btn-light btn-outline-style py-3" href="contact.html" title="Contact Us!"><span
              className="fa fa-location-arrow mr-2"></span>Contact Us!</a>
        </div>
      </div>
    </div>
    </div>
</section>

    <footer className="w3l-footer">
      <div className="footer-29 py-5">
        <div className="container pb-lg-3">
          <div className="row footer-top-29">
            <div className="col-md-6 footer-list-29 footer-1 mt-md-4">
              <h6 className="footer-title-29">Contact Us</h6>
              <ul>
                <li>
                  <span className="fa fa-map-marker"></span>
                  <p> Workflow, 433 California St, Suite 300 San Francisco, <br/>CA 94104, USA</p>
                </li>
                <li>
                  <span className="fa fa-phone"></span>
                  <a href="tel:+44 99 555 42"> +44 99 555 42</a></li>
                <li>
                  <span className="fa fa-envelope-open-o"></span>
                  <a href="mailto:mailid@mail.com" className="mail">
                    mailid@mail.com</a></li>
              </ul>
              <div className="main-social-footer-29">
                <a href="#facebook" className="facebook"><span className="fa fa-facebook"></span></a>
                <a href="#twitter" className="twitter"><span className="fa fa-twitter"></span></a>
                <a href="#instagram" className="instagram"><span className="fa fa-instagram"></span></a>
                <a href="#google-plus" className="google-plus"><span className="fa fa-google-plus"></span></a>
                <a href="#linkedin" className="linkedin"><span className="fa fa-linkedin"></span></a>
              </div>
            </div>

            <div className="col-md-6 footer-list-29 footer-4 mt-md-4 mt-5">
              <h6 className="footer-title-29">Subscribe</h6>
              <p>Always know what’s happening in the
                world of applications. Recieve all
                latest post in your inbox.</p>
              <form action="#" method="post" className="rightside-form mt-4">
                <input type="email" name="email" placeholder="Enter your email" />
                <button type="submit" className="btn"><span className="fa fa-search" aria-hidden="true"></span></button>
              </form>
            </div>
          </div>
          <div className="row bottom-copies">
            <p className="copy-footer-29 col-lg-7 text-lg-left text-center">© 2020 Worksmart. All rights reserved | Design by <a
                href="https://w3layouts.com/">W3Layouts</a></p>
            <ul className="list-btm-29 col-lg-5 text-lg-right text-center">
              <li><a href="index.html">Home</a></li>
              <li><a href="about.html">About</a></li>
              <li><a href="contact.html">Contact</a></li>
            </ul>
          </div>
        </div>
      </div>

      <button onclick="topFunction()" id="movetop" className="bg-primary" title="Go to top">
        <span className="fa fa-angle-up"></span>
      </button>
    </footer>      
    </>);
}
export default Home;