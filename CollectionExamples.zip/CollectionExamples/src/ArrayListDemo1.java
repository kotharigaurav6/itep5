import java.util.*;
public class ArrayListDemo1 
{
    public static void main(String[] args) {
        ArrayList list = new ArrayList();
           list.add(100);
           list.add(true);
           list.add(56.67);
           list.add("Hello User");
           list.add('a');
           
           System.out.println("Elements : "+list);
    }
}
 