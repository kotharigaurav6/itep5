import java.util.*;
public class QueueDemo2 
{
    public static void main(String[] args) {
        PriorityQueue<String> queue = new PriorityQueue<>();
      queue.offer("Jackson");
        queue.add("Andrew");
      queue.offer("simon");
      System.out.println("Elements : "+queue);
              
//        System.out.println("element : "+queue.element());
//        System.out.println("Elements : "+queue);

//        System.out.println("peek : "+queue.peek());
//        System.out.println("Elements : "+queue);

//        System.out.println("remove : "+queue.remove());
//        System.out.println("Elements : "+queue);

//        System.out.println("poll : "+queue.poll());
//        System.out.println("Elements : "+queue);
      
    }
}
