import { useLocation,useNavigate } from "react-router-dom";
import { useDispatch,useSelector } from "react-redux";
import { useEffect } from "react";
import { setNavBar } from "../store/commonSlice.js";
import jscookie from 'js-cookie';
function CandidateHome(){
    const location = useLocation();
  //  const candidateemail = useSelector(state=>state.candidateSlice.email);
    const dispatch = useDispatch();
  //  console.log(candidateemail);
    const navigate = useNavigate();
    const candidate_email = jscookie.get("candidate_email");

    useEffect(()=>{
      if(candidate_email=="null"){
        dispatch(setNavBar("home"));
        navigate("/");
      }
      else  
        dispatch(setNavBar("candidateHome"));
    },[]);
  

    return (<>
    <div class="w3l-index-block1">
  <div class="content py-5">
    <div class="container py-lg-4">
      <div class="row align-items-center">
        <div class="col-lg-5 content-left">
          <h3>Candidate Panel</h3>
          <h5>{candidate_email}</h5>
          <p class="mt-3 mb-lg-5 mb-4">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
          <a href="about.html" class="btn btn-primary btn-style">Get Started</a>
        </div>
        <div class="col-lg-7 content-photo mt-lg-0 mt-5">
          <img src="assets/images/main.jpg" class="img-fluid" alt="main image"/>
        </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
    </>);
}
export default CandidateHome;