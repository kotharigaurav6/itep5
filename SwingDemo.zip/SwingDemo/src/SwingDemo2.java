import javax.swing.JFrame;
public class SwingDemo2 extends JFrame{

    public SwingDemo2(){
            setTitle("My First Example");
            setLayout(null);
            setSize(400, 400);
            setLocation(200, 200);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);
    }
            
        public static void main(String[] args) {
            new SwingDemo2();
        }
}
