package B;
import A.Aclass;

public class Bclass 
{
    public void display(){
        System.out.println("display method of class B called");
        Aclass obj = new Aclass();
        obj.show();
    }
}
