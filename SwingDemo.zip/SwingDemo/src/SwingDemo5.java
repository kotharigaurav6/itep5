import javax.swing.JFrame;
import javax.swing.*;

public class SwingDemo5 extends JFrame{
    JMenuBar mb;
    JMenu m;
    JMenuItem i1,i2;
    
    public SwingDemo5(){
            setTitle("My First Example");
            setLayout(null);
            setSize(600, 600);
            setLocation(200, 200);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
            mb = new JMenuBar();
            m = new JMenu("Open");
            i1 = new JMenuItem("Save");
            i2 = new JMenuItem("Edit");
            
            setJMenuBar(mb);
            mb.add(m);
            m.add(i1);
            m.add(i2);
            
            setVisible(true);
    }
        public static void main(String[] args) {
            new SwingDemo5();
        }
}
