public class WrapperDemo9 
{
    public static void main(String[] args) {

           double d = Double.parseDouble("456.67");
           boolean b = Boolean.parseBoolean("true");
           System.out.println("d : "+d+"\nb : "+b);
    }
}






