import { createSlice } from "@reduxjs/toolkit";
import axios from 'axios';
import { candidate_requestedUrl,appliedVacancy_requestedUrl } from "../urls.js";
import jscookie from 'js-cookie';
var candidate_token = jscookie.get("candidate_jwt_token");

const initialState = {
    message:"",
//    email:""
}

const candidateSlice = createSlice({
    name:'candidateSlice',
    initialState,
    reducers : {
        setMessage:(state,action)=>{
            state.message = action.payload;
        },
        // setEmail : (state,action)=>{
        //     state.email = action.payload
        // }
    }
});

export const addCandidate =async (formData)=>{  
    try{
        console.log("form data : ",formData);
        var result = await axios.post(candidate_requestedUrl+'/candidateRegistration',formData); 
        console.log("candidateSlice : ",result);
        console.log("token : ",result.data.token);
        jscookie.set('candidate_jwt_token',result.data.token,{expires:1});
    }catch(err){
        console.log("error in candidateSlice : ",err);
    }
}

export const candidateLogin =async (candidateCredential)=>{  
    try{
        console.log(candidateCredential);
        var result = await axios.post(candidate_requestedUrl+'/candidateLogin',candidateCredential); 
        console.log("candidateSlice : ",result);
        console.log("token : ",result.data.token);
        if(result.status==201)
           jscookie.set("candidate_email",candidateCredential.email);
 
        jscookie.set('candidate_jwt_token',result.data.token,{expires:1});
        return result;
    }catch(err){
        console.log("error in candidateSlice : ",err);
    }
}

export const viewVacancyList =async ()=>{  
    try{
        var result = await axios.get(candidate_requestedUrl+'/viewVacancy?candidateToken='+candidate_token); 
        console.log("vacancyList : ",result);
        return result;
    }catch(err){
        console.log("error in candidate vacancyList : ",err);
    }
}

export const candidateApplyVacancy = async(vacancyObj)=>{
    try{
        var result = await axios.post(appliedVacancy_requestedUrl+'/applyVacancy?candidateToken='+candidate_token,vacancyObj);
        console.log("result : ",result);
        return result;
    }catch(err){
        console.log("error while candidate applying for vacancy : ",err);
    }
}
export const viewVacancyStatus =async ()=>{  
    try{
        var result = await axios.get(candidate_requestedUrl+'/viewStatus?candidateToken='+candidate_token); 
        console.log("vacancyList : ",result);
        return result;
    }catch(err){
        console.log("error in candidate vacancy status List : ",err);
    }
}

//export const {setEmail} = candidateSlice.actions;
export default candidateSlice.reducer;