import {viewAppliedCandidateList} from '../store/vacancySlice.js';
import {useEffect,useState} from 'react';
import { useSelector,useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { setNavBar } from '../store/commonSlice.js';
import { updateStatus } from '../store/recruiterSlice.js';
function AppliedCandidateList(){
    const dispatch = useDispatch();
    const [appliedCandidateList,setAppliedCandidateList]  = useState([]);
    const [appliedCandidateDocs,setAppliedCandidateDocs] = useState([]);
    useEffect(()=>{
        dispatch(setNavBar("recruiterHome"));

        var res = viewAppliedCandidateList();
        res.then((vacancy)=>{
            if(vacancy.status==200){
                setAppliedCandidateList(vacancy.data.result);
                setAppliedCandidateDocs(vacancy.data.candidateDocs);    
            }
        }).catch((err)=>{
            console.log(err);
        });
    },[]);

    const recruiterStatusUpdate = (vacancyId)=>{
        var res = updateStatus(vacancyId);
       console.log("##########",res);
        res.then((recruiter)=>{
            if(recruiter.status==200){
                console.log("$$$$$$$$$$$ : ",recruiter);
                setAppliedCandidateList(recruiter.data.result);
                setAppliedCandidateDocs(recruiter.data.candidateDocs);   
            }
        }).catch((err)=>{
            console.log(err);
        });
    }

    return (<>
    <section class="w3l-index2" id="services">
  <div class="features-main py-5 text-center">
    <div class="container py-lg-3">
      <div class="heading mx-auto">
        <h4 class="head">Applied Candidate List</h4>
      <br/>  
      </div>

        <table border="1" style={{fontSize:"11px"}} cellPadding="10" cellSpacing="0" width="100%">
            <thead>
                <tr>
                    <th>Vacancy Id</th>
                    <th>Candidate Email</th>
                    <th>Recruiter Email</th>
                    <th>Post</th>
                    <th>Resume/CV</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            {
                    appliedCandidateList.map((vacancy,i)=>{
                        return(<tr>
                            <td>{vacancy.vid}</td>
                            <td>{vacancy.candidateemail}</td>
                            <td>{vacancy.recruiteremail}</td>
                            <td>{vacancy.post}</td>
                            {/* <td><a href={"http://localhost:3000/assets/images/"+appliedCandidateDocs[i]}>{appliedCandidateDocs[i]}</a></td>     */}
                            <td><Link to={"/assets/images/"+appliedCandidateDocs[i]} target="_blank" download>Download</Link></td>
                            <td><button onClick={()=>{recruiterStatusUpdate(vacancy.vid)}}>{vacancy.status}</button></td>
             
                        </tr>)
                    })
                }
                {/* <%result.forEach((candidateList,i)=>{%>
                  <tr>
                    <td><%=candidateList.vid%></td>
                    <td><%=candidateList.candidateemail%></td>
                    <td><%=candidateList.recruiteremail%></td>
                    <td><%=candidateList.post%></td>
                    <td><a href="/assets/images/<%=candidateDocs[i]%>">Download Resume/CV</a></td>
                    <td><a href="/recruiter/updateCandidateStatus?vid=<%=candidateList.vid%>"><%=candidateList.status%></a></td>
                  </tr>  
                <%})%> */}
            </tbody>
            <tfoot>
                <tr>
                    <th>Vacancy Id</th>
                    <th>Candidate Email</th>
                    <th>Recruiter Email</th>
                    <th>Post</th>
                    <th>Resume/CV</th>
                    <th>Status</th>
                </tr>
            </tfoot>
        </table>

    </div>
  </div>
</section>

    </>);
}
export default AppliedCandidateList;