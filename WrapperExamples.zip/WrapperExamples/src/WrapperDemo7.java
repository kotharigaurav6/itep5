public class WrapperDemo7 
{
    public static void main(String[] args) {
        Integer obj = new Integer(130);
        System.out.println(""+obj.intValue());
        System.out.println(""+obj.shortValue());
        System.out.println(""+obj.byteValue());
        System.out.println(""+obj.longValue());
        System.out.println(""+obj.floatValue());
        System.out.println(""+obj.doubleValue());
 
    }
}






