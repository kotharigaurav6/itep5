export const recruiter_requestedUrl = "http://localhost:3000/recruiter";
export const admin_requestedUrl = "http://localhost:3000/admin";
export const vacancy_requestedUrl = "http://localhost:3000/vacancy";
export const candidate_requestedUrl = "http://localhost:3000/candidate";
export const appliedVacancy_requestedUrl = "http://localhost:3000/appliedvacancy";
