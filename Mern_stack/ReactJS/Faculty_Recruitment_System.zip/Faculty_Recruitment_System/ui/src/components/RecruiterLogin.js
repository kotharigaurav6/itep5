import {Link,useLocation,useNavigate} from 'react-router-dom';
import { recruiterLogin } from '../store/recruiterSlice.js';
import {useState} from 'react';
import { useDispatch } from 'react-redux';
//import { setEmail } from '../store/recruiterSlice.js';

function RecruiterLogin(){
const location = useLocation();
const dispatch = useDispatch();  
/* ---- extract message from url -----*/
const urlParams = new URLSearchParams(window.location.search);
const message = urlParams.get('message');
console.log("message : ",message);
/* ---- extract message from url -----*/

const [recruiterCredential,setRecruiterCredential] = useState();
const navigate = useNavigate();
const getData = (event)=>{
  const {name,value} = event.target;
  setRecruiterCredential({
    ...recruiterCredential,
    [name]:value
  });
}
const handleSubmit = (event)=>{
event.preventDefault();
  var result = recruiterLogin(recruiterCredential);
  console.log("result of recruiter : ",result);
  result.then((resultData)=>{
       console.log(resultData);
       console.log("result of recruiter email : ",resultData.data.recruiteremail);
       console.log("result of recruiter status : ",resultData.status);
       if(resultData.status==201){
//        dispatch(setEmail(resultData.data.recruiteremail));
        navigate("/recruiterHome",{
            state:{
              email : resultData.data.recruiteremail
            }
          });
        }else if(resultData.status==203){
          navigate("/recruiterLogin",{
            state:{
              message : resultData.data.message
            }
          });
        }
  });
}

return (<>
  <section style={{marginTop: "-50px"}} className="w3l-index3">
  <div className="midd-w3 py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row">
        <div className="col-lg-6 left-wthree-img text-right">
          <img src="assets/images/g5.jpg" alt="" className="img-fluid rounded" />
        </div>
        <div className="col-lg-6 mt-lg-0 mt-5 about-right-faq">
            <br/><br/>
          <h3 className="text-da">Recruiter Login</h3>
          {location.state==null ? (message!=null ? message : "") : (message==null ? location.state.message : message)}     
          <br/>
          {/* "/recruiter/recruiterLogin" */}
          
            <form onSubmit={handleSubmit} className="form-group" method="post">
                <input className="form-control" onChange={getData} type="email" placeholder="Enter Email" id="email" name="email"/> <br/>
                <input className="form-control" onChange={getData} type="password" placeholder="Enter Password" id="password" name="password"/> <br/>
                <input className="btn btn-primary btn-block" type="submit" value="Login"/> 
                <input className="btn btn-danger btn-block" type="reset" value="Reset"/>
                <br/>
            </form>
          <Link to="/recruiterRegister">
          <span className="btn btn-link">Yet Not Register ? Register Here</span>
          </Link>
        </div>
      </div>
    </div>
  </div>
</section>

</>);
}
export default RecruiterLogin;