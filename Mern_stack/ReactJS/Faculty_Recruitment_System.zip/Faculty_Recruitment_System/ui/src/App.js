import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar.js';
import {Routes,Route} from 'react-router-dom';
import CandidateLogin from './components/CandidateLogin.js';
import RecruiterLogin from './components/RecruiterLogin.js';
import Home from './components/Home.js';
import Admin from './components/Admin.js';
import RecruiterRegistration from './components/RecruiterRegistration.js';
import CandidateRegistration from './components/CandidateRegistration.js';
import AdminHome from './components/AdminHome.js';
import RecruiterList from './components/RecruiterList.js';
import RecruiterHome from './components/RecruiterHome.js';
import AddVacancy from './components/AddVacancy.js';
import RecruiterVacancyList from './components/RecruiterVacancyList.js';
import CandidateHome from './components/CandidateHome.js';
import CandidateVacancyList from './components/CandidateVacancyList.js';
import CandidateVacancyStatus from './components/CandidateVacancyStatus.js';
import AppliedCandidateList from './components/AppliedCandidateList.js';

function App() {
  return (<>
    <Navbar/>
    <Routes>
      <Route path="/" element={<Home/>}></Route>
      <Route path="/admin" element={<Admin/>}></Route>
      <Route path="/adminHome" element={<AdminHome/>}></Route>
      <Route path="/recruiterList" element={<RecruiterList/>}></Route>
      <Route path="/candidateLogin" element={<CandidateLogin/>}></Route>
      <Route path="/recruiterLogin" element={<RecruiterLogin/>}></Route>
      <Route path="/recruiterHome" element={<RecruiterHome/>}></Route>
      <Route path="/addVacancy" element={<AddVacancy/>}></Route>
      <Route path="/recruiterRegister" element={<RecruiterRegistration/>}></Route>
      <Route path="/recruiterViewVacancy" element={<RecruiterVacancyList/>}></Route>
      <Route path="/candidateRegister" element={<CandidateRegistration/>}></Route>
      <Route path="/candidateViewVacancy" element={<CandidateVacancyList/>}></Route>
      <Route path="/candidateVacancyStatus" element={<CandidateVacancyStatus/>}></Route>
      <Route path="/appliedCandidateList" element={<AppliedCandidateList/>}></Route>
      <Route path="/candidateHome" element={<CandidateHome/>}></Route>
      
    </Routes>
  </>
  );
}

export default App;
