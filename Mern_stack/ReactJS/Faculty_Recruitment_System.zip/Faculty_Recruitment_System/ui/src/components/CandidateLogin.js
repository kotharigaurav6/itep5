import {Link,useLocation,useNavigate} from 'react-router-dom';
import { candidateLogin } from '../store/candidateSlice.js';
import {useState} from 'react';
import { useDispatch } from 'react-redux';
function CandidateLogin(){
const location = useLocation();  
/* ---- extract message from url -----*/
const urlParams = new URLSearchParams(window.location.search);
const message = urlParams.get('message');
console.log("message : ",message);
/* ---- extract message from url -----*/

const [candidateCredential,setCandidateCredential] = useState();
const navigate = useNavigate();
const dispatch = useDispatch();

const getData = (event)=>{
  const {name,value} = event.target;
  setCandidateCredential({
    ...candidateCredential,
    [name]:value
  });
}
const handleSubmit = (event)=>{
event.preventDefault();
  var result = candidateLogin(candidateCredential);
  console.log("result of candidate : ",result);
  result.then((resultData)=>{
       console.log(resultData);
       console.log("result of candidate email : ",resultData.data.candidateemail);
       console.log("result of candidate status : ",resultData.status);
       if(resultData.status==201){
   //     dispatch(setEmail(resultData.data.candidateemail));
        navigate("/candidateHome",{
            state:{
              email : resultData.data.candidateemail
            }
          });
        }else if(resultData.status==203){
          navigate("/candidateLogin",{
            state:{
              message : resultData.data.message
            }
          });
        }
  });
}

return (<>
  <section style={{marginTop: "-50px"}} className="w3l-index3">
  <div className="midd-w3 py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row">
        <div className="col-lg-6 left-wthree-img text-right">
          <img src="assets/images/g5.jpg" alt="" className="img-fluid rounded" />
        </div>
        <div className="col-lg-6 mt-lg-0 mt-5 about-right-faq">
            <br/><br/>
          <h3 className="text-da">Candidate Login</h3>
          {location.state==null ? (message!=null ? message : "") : (message==null ? location.state.message : message)}     
          <br/>
          {/* "/candidate/candidateLogin" */}
          
            <form onSubmit={handleSubmit} className="form-group" method="post">
                <input className="form-control" onChange={getData} type="email" placeholder="Enter Email" id="email" name="email"/> <br/>
                <input className="form-control" onChange={getData} type="password" placeholder="Enter Password" id="password" name="password"/> <br/>
                <input className="btn btn-primary btn-block" type="submit" value="Login"/> 
                <input className="btn btn-danger btn-block" type="reset" value="Reset"/>
                <br/>
            </form>
          <Link to="/candidateRegister">
          <span className="btn btn-link">Yet Not Register ? Register Here</span>
          </Link>
        </div>
      </div>
    </div>
  </div>
</section>

</>);
}
export default CandidateLogin;