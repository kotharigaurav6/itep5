import {configureStore} from '@reduxjs/toolkit';
import commonSlice from './commonSlice.js';
import recruiterSlice from './recruiterSlice.js';
import candidateSlice from './candidateSlice.js';
import adminSlice from './adminSlice.js';
export default configureStore({
    reducer : {
        commonSlice : commonSlice,
        recruiterSlice : recruiterSlice,
        candidateSlice : candidateSlice,
        adminSlice : adminSlice
    }
});