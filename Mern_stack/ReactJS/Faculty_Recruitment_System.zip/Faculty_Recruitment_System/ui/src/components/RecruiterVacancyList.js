import {deleteVacancy, viewVacancyList} from '../store/vacancySlice.js';
import {useEffect,useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setNavBar } from '../store/commonSlice.js';
function RecruiterVacancyList(){
    const navigate = useNavigate();
    const dispatch = useDispatch();
      const [vacancyList,setVacancyList]  = useState([]);
      useEffect(()=>{
        dispatch(setNavBar("recruiterHome"));

          var res = viewVacancyList();
          res.then((vacancy)=>{
              if(vacancy.status==203){
                  navigate("/recruiterLogin",{
                      state:{
                          message:vacancy.data.message
                      }
                  });
              }else if(vacancy.status==200){
                  setVacancyList(vacancy.data.result);
              }
          }).catch((err)=>{
              console.log(err);
          });
      },[]);
    const delete_Vacancy = (vacancyId)=>{
        var res = deleteVacancy(vacancyId);
        res.then((vacancy)=>{
            if(vacancy.status==203){
                navigate("/recruiterLogin",{
                    state:{
                        message:vacancy.data.message
                    }
                });
            }else if(vacancy.status==200){
                setVacancyList(vacancy.data.result);
            }
        }).catch((err)=>{
            console.log(err);
        });
    }
    const update_vacancy = (vacancy)=>{
        navigate("/addVacancy",{
            state:{
                vacancyobj : vacancy
            }
        });
    }
    return (<>
    <section class="w3l-index2" id="services">
  <div class="features-main py-5 text-center">
    <div class="container py-lg-3">
      <div class="heading mx-auto">
        <h4 class="head">Vacancy List</h4>
      <br/>  
      </div>

        <table border="1" cellpadding="10" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Post</th>
                    <th>Subject</th>
                    <th>Location</th>
                    <th>Criteria</th>
                    <th>Experience</th>
                    <th>Duration</th>
                    <th>Vacancy</th>
                    <th>Salary</th>
                    <th>Adv.Date</th>
                    <th>LastDate</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
            {
                vacancyList.map((vacancy)=>{
                    return (<tr>
                        <td>{vacancy.post}</td>
                        <td>{vacancy.subject}</td>
                        <td>{vacancy.location}</td>
                        <td>{vacancy.criteria}</td>
                        <td>{vacancy.experience}</td>
                        <td>{vacancy.duration}</td>
                        <td>{vacancy.vacancy}</td>
                        <td>{vacancy.salary}</td>
                        <td>{vacancy.advdate}</td>
                        <td>{vacancy.lastdate}</td>
                        <td><button onClick={()=>{update_vacancy(vacancy)}}>Update</button></td>
                        <td><button onClick={()=>{delete_Vacancy(vacancy._id)}}>Delete</button></td>
                    </tr>);
                })
            }
                {/* <%result.forEach((vacancyList)=>{%>
                  <tr>
                    <td><%=vacancyList.post%></td>
                    <td><%=vacancyList.subject%></td>
                    <td><%=vacancyList.location%></td>
                    <td><%=vacancyList.criteria%></td>
                    <td><%=vacancyList.experience%></td>
                    <td><%=vacancyList.duration%></td>
                    <td><%=vacancyList.vacancy%></td>
                    <td><%=vacancyList.salary%></td>
                    <td><%=vacancyList.advdate%></td>
                    <td><%=vacancyList.lastdate%></td>
                    <td><a href="/vacancy/updateVacancy?_id=<%=vacancyList._id%>">Update</a></td>
                    <td><a href="/vacancy/deleteVacancy?_id=<%=vacancyList._id%>">Delete</a></td>
                  </tr>  
                <%})%> */}
            </tbody>
            <tfoot>
                <tr>
                    <th>Post</th>
                    <th>Subject</th>
                    <th>Location</th>
                    <th>Criteria</th>
                    <th>Experience</th>
                    <th>Duration</th>
                    <th>Vacancy</th>
                    <th>Salary</th>
                    <th>Adv.Date</th>
                    <th>LastDate</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
            </tfoot>
        </table>

    </div>
  </div>
</section>

    </>);
}
export default RecruiterVacancyList;