import java.util.*;
public class MapDemo2 
{
    public static void main(String[] args) {
      //  HashMap<String,String> map = new HashMap<>();
      //  LinkedHashMap<String,String> map = new LinkedHashMap<>();
        TreeMap<String,String> map = new TreeMap<>();
        
        map.put("26-01-2023", "Republic Day");
        map.put("15-08-2023", "Independence Day");
        map.put("02-10-2023", "Gandhi Jayanti");
        map.put("05-09-2023", "Teacher's Day");
        
        /*
            Set set = map.entrySet();
            Iterator itr = set.iterator();
            while(itr.hasNext()){
              //  System.out.println(""+itr.next());
              Map.Entry obj = (Map.Entry)itr.next();
                System.out.println("Key : "+obj.getKey()+"\tValue : "+obj.getValue());
            }
        */
            
        for(Map.Entry obj : map.entrySet()){
              System.out.println("Key : "+obj.getKey()+"\tValue : "+obj.getValue());       
        }
    }
}
