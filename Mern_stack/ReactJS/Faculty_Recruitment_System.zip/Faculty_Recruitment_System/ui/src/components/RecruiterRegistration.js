import { addRecruiter } from "../store/recruiterSlice.js";
import {useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';
import {useSelector} from 'react-redux';

function RecruiterRegistration(){
    const [recruiter,setRecruiter] = useState({});
    const navigate = useNavigate();
    const getData = (event)=>{
        const {name,value} = event.target;
        setRecruiter({
            ...recruiter,
            [name]:value
        });
    }
    const handleSubmit = (event)=>{
        event.preventDefault();
        addRecruiter(recruiter);
        navigate("/recruiterLogin",{
          state:{
            message:"Email Sent | Please verify and wait for admin approval"
          }
        });
    }
    return (<>
      <section style={{marginTop: "-50px"}} className="w3l-index3">
  <div className="midd-w3 py-5">
    <div className="container py-xl-5 py-lg-3">
      <div className="row">
        <div className="col-lg-6 left-wthree-img text-right">
          <img src="assets/images/g5.jpg" alt="" className="img-fluid rounded" />
        </div>
        <div className="col-lg-6 mt-lg-0 mt-5 about-right-faq">
          <h3 className="text-da">Recruiter Registration</h3>
          <br />
{/* "/recruiter/recruiterRegistration" */}
          <form onSubmit={handleSubmit} method="post" className="form-group">
            <input onChange={getData} required className="form-control" type="text" placeholder="Enter Recruiter Name" id="name" name="name" />
            
            <select onChange={getData} required name="type" id="type" className="form-control">
                <option value="">Select Recruiter Type</option>
                <option value="School">School</option>
                <option value="College">College</option>
                <option value="Professional Institute">Professional Institute</option>
            </select>
            
            <input onChange={getData} required className="form-control" type="email" placeholder="Enter Email" id="email" name="email" />
            
            <input onChange={getData} required className="form-control" type="password" placeholder="Enter Password" id="password" name="password" />
            
            <input onChange={getData} required className="form-control" type="contact" placeholder="Enter 10-digit mobile number" id="contact" name="contact" />
            
            <textarea onChange={getData} required name="address" id="address" className="form-control" placeholder="Enter Address"></textarea>
            
            <input className="btn btn-primary btn-block" type="submit" value="Register" /> 
            
            <input className="btn btn-danger btn-block" type="reset" value="Reset" />
            
          </form>
          <Link to="/recruiterLogin"> <span className="btn btn-link">Already Registered ? Login Here</span></Link>
          
        </div>
      </div>
    </div>
  </div>
</section>
  
    </>);
}

export default RecruiterRegistration;