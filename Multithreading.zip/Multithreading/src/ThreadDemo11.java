public class ThreadDemo11
{
    public static void main(String[] args) {
/*
        Runnable obj = new Runnable(){
            public void run(){
                System.out.println("run method executes");
            }
        };
        Thread th = new Thread(obj);
        th.start();
*/
 /*       
        Thread th = new Thread(new Runnable(){
            public void run(){
                System.out.println("run method executes");
            }
        });
        th.start();
*/
        
        new Thread(new Runnable(){
            public void run(){
                System.out.println("run method executes");
            }
        }).start();
        
    }
}
