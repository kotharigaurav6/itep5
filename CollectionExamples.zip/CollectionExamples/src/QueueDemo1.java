import java.util.*;
public class QueueDemo1 
{
    public static void main(String[] args) {
        PriorityQueue<String> queue = new PriorityQueue<>();
        queue.add("Andrew");
        queue.add("Simon");
        queue.add("Simon");
        queue.add("Jackson");
        queue.add("Jack");
            
        Iterator itr= queue.iterator();
        while(itr.hasNext()){
            System.out.print("\t"+itr.next());
        }
        
    }
}
